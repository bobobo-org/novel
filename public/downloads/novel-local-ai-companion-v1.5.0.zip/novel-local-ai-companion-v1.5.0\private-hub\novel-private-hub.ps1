param(
  [ValidateSet('start','status','stop','restart','pair','revoke','diagnose','provision-preview-key','provision-production-key')]
  [string]$Command = 'status'
)

$ErrorActionPreference = 'Stop'
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$launcher = Join-Path $scriptRoot 'launcher.mjs'

function Write-LauncherError([string]$Code, [string]$Message, [string]$NextStep) {
  [pscustomobject]@{
    ok = $false
    errorCode = $Code
    message = $Message
    nextStep = $NextStep
  } | ConvertTo-Json -Depth 4
}

$nodeCandidates = @()
if ($env:NOVEL_NODE_PATH) { $nodeCandidates += $env:NOVEL_NODE_PATH }
$nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
if ($nodeCommand) { $nodeCandidates += $nodeCommand.Source }
$nodeCandidates += @(
  (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe')
)
$nodePath = $nodeCandidates |
  Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } |
  Select-Object -First 1

if (-not $nodePath) {
  Write-LauncherError 'LAUNCHER_NODE_NOT_FOUND' 'Node.js was not found.' 'Install Node.js 22 LTS or set NOVEL_NODE_PATH to node.exe.'
  exit 1
}

try {
  $version = (& $nodePath --version).TrimStart('v')
  $major = [int]($version.Split('.')[0])
  if ($major -lt 22) {
    Write-LauncherError 'LAUNCHER_NODE_UNSUPPORTED' "Node.js $version is unsupported." 'Install Node.js 22 LTS or set NOVEL_NODE_PATH.'
    exit 1
  }
  & $nodePath $launcher $Command
  exit $LASTEXITCODE
} catch {
  Write-LauncherError 'LAUNCHER_WRAPPER_FAILED' $_.Exception.Message 'Run diagnose and verify the local runtime directory.'
  exit 1
}
