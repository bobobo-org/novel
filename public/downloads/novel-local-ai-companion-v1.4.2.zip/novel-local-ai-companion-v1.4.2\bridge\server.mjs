import http from "node:http";
import os from "node:os";
import path from "node:path";
import { appendFile, rm, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import {
  BRIDGE_PROTOCOL, BRIDGE_VERSION, DEFAULT_LIMITS, BridgeError, PairingStore, RateLimiter, RequestLedger, WorkLimiter,
  assertOrigin, assertProtocol, buildOriginAllowlist, modelProfileFromTag, normalizeOllamaEndpoint, sanitizeLog, TRUSTED_AUTO_SESSION_ORIGINS, validateHostHeader, validateLoopbackHost,
} from "./bridge-core.mjs";
import {
  assertRuntimeCacheNamespace,
} from "../cache/cache-contract.mjs";
import { LocalSQLiteCacheStore } from "../cache/sqlite-cache-store.mjs";

export const LOCAL_BRIDGE_MODEL_DISCOVERY_SERVER_TIMEOUT_MS = 5_000;
export const LOCAL_BRIDGE_MODEL_INFERENCE_SERVER_TIMEOUT_MS = 45_000;
export const LOCAL_BRIDGE_MODEL_VERIFICATION_CACHE_TTL_MS = 10 * 60_000;
const jsonHeaders = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store, max-age=0" };
const characterExtractionFormat = {
  type: "object", additionalProperties: false, required: ["schemaVersion", "facts"],
  properties: {
    schemaVersion: { type: "string", const: "local-quality-guard-v1" },
    facts: { type: "array", maxItems: 3, items: { type: "object", additionalProperties: false, required: ["entityId", "field", "value", "evidenceText", "confidence"], properties: {
      entityId: { type: "string", maxLength: 160 },
      field: { type: "string", enum: ["age", "location", "identity", "lifeStatus"] },
      value: { type: ["string", "number", "boolean", "null"] },
      evidenceText: { type: "string", maxLength: 160 },
      confidence: { type: "number", minimum: 0, maximum: 1 },
    } } },
  },
};

function sendJson(response, status, body, origin) {
  response.writeHead(status, { ...jsonHeaders, ...(origin ? { "Access-Control-Allow-Origin": origin, Vary: "Origin" } : {}) });
  response.end(JSON.stringify(body));
}

async function readJson(request, maxBytes) {
  if (!String(request.headers["content-type"] || "").toLowerCase().startsWith("application/json")) throw new BridgeError("LOCAL_SECURITY_POLICY_VIOLATION", "Content-Type must be application/json.", 415);
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw new BridgeError("LOCAL_REQUEST_TOO_LARGE", "Request body exceeds the local bridge limit.", 413);
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { throw new BridgeError("OLLAMA_REQUEST_REJECTED", "Request body is not valid JSON.", 400); }
}

function bearer(request) {
  const value = String(request.headers.authorization || "");
  return value.startsWith("Bearer ") ? value.slice(7) : "";
}

function cacheRequestError(error) {
  if (error instanceof BridgeError) return error;
  const code = String(error?.code || "CLOSED_AI_CACHE_REQUEST_INVALID");
  const clientError = code === "CLOSED_AI_NAMESPACE_INVALID"
    || code === "CLOSED_AI_CACHE_INVALIDATION_NOT_TARGETED"
    || code === "CLOSED_AI_CACHE_LAYER_INVALID";
  return new BridgeError(
    code,
    error instanceof Error ? error.message : "Closed AI cache request failed.",
    clientError ? 400 : 500,
    false,
  );
}

async function ollamaFetch(endpoint, path, init = {}, timeoutMs = 5_000, controller) {
  const localController = controller || new AbortController();
  const timer = setTimeout(() => localController.abort("timeout"), timeoutMs);
  try {
    const response = await fetch(`${endpoint}${path}`, { ...init, redirect: "error", signal: localController.signal, headers: { "Content-Type": "application/json", ...(init.headers || {}) } });
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      const missing = response.status === 404 || /not found/i.test(text);
      throw new BridgeError(missing ? "OLLAMA_MODEL_NOT_FOUND" : response.status >= 500 ? "OLLAMA_MODEL_LOAD_FAILED" : "OLLAMA_REQUEST_REJECTED", `Ollama HTTP ${response.status}.`, missing ? 404 : 502, response.status >= 500);
    }
    return response;
  } catch (error) {
    if (error instanceof BridgeError) throw error;
    if (localController.signal.aborted) throw new BridgeError(localController.signal.reason === "cancelled" ? "OLLAMA_CANCELLED" : "OLLAMA_TIMEOUT", "Ollama request was cancelled or timed out.", 408, true);
    throw new BridgeError("OLLAMA_UNREACHABLE", "Ollama is not reachable on local loopback.", 503, true);
  } finally { clearTimeout(timer); }
}

export function createBridgeServer(options = {}) {
  const host = validateLoopbackHost(options.host || process.env.BRIDGE_HOST || "127.0.0.1");
  const port = Number(options.port || process.env.BRIDGE_PORT || 3217);
  const ollamaEndpoint = normalizeOllamaEndpoint(options.ollamaEndpoint || process.env.OLLAMA_ENDPOINT || "http://127.0.0.1:11434");
  const limits = { ...DEFAULT_LIMITS, ...(options.limits || {}) };
  const allowlist = buildOriginAllowlist(options.extraOrigins ?? process.env.BRIDGE_ALLOWED_ORIGINS ?? "");
  const trustedAutoSessionOrigins = new Set(
    (options.trustedAutoSessionOrigins === false
      ? []
      : Array.isArray(options.trustedAutoSessionOrigins)
        ? options.trustedAutoSessionOrigins
        : TRUSTED_AUTO_SESSION_ORIGINS
    ).filter((origin) => allowlist.has(origin)),
  );
  const envPairingTtlMs = Number(process.env.BRIDGE_PAIRING_TTL_MS || 0);
  const envSessionTtlMs = Number(process.env.BRIDGE_SESSION_TTL_MS || 0);
  const pairingOptions = options.pairingOptions || {
    ...(Number.isFinite(envPairingTtlMs) && envPairingTtlMs > 0 ? { pairingTtlMs: envPairingTtlMs } : {}),
    ...(Number.isFinite(envSessionTtlMs) && envSessionTtlMs > 0 ? { sessionTtlMs: envSessionTtlMs } : {}),
  };
  const pairing = new PairingStore(pairingOptions);
  const inferenceRate = new RateLimiter(limits.rateLimitPerMinute);
  const controlRate = new RateLimiter(
    Math.max(limits.rateLimitPerMinute * 8, 240),
  );
  const ledger = new RequestLedger();
  const work = new WorkLimiter(limits);
  const active = new Map();
  const modelVerificationCache = new Map();
  const modelVerificationInFlight = new Map();
  const logs = [];
  const testMode = options.testMode ?? process.env.BRIDGE_TEST_MODE === "1";
  const pairingFile = options.pairingFile ?? process.env.BRIDGE_PAIRING_FILE ?? "";
  const accessLogPath = options.accessLogPath ?? process.env.BRIDGE_ACCESS_LOG ?? "";
  const accessLogs = [];
  const runtimeDir = options.runtimeDir
    || process.env.NOVEL_BRIDGE_RUNTIME_DIR
    || path.join(process.env.LOCALAPPDATA || os.homedir(), "NovelLocalBridge");
  const cache = options.cacheStore ?? new LocalSQLiteCacheStore({
    filePath: options.cacheFile
      || process.env.NOVEL_BRIDGE_CACHE_FILE
      || path.join(runtimeDir, "cache", "closed-ai-cache.sqlite"),
  });

  async function publishPairingCode(pending, origin) {
    if (!pairingFile) {
      if (!testMode) process.stderr.write(`Local Bridge pairing code: ${pending.code}\n`);
      return;
    }
    await writeFile(pairingFile, JSON.stringify({ pairingId: pending.pairingId, code: pending.code, expiresAt: pending.expiresAt, origin, instanceId: pairing.instanceId }), { mode: 0o600 });
  }
  async function clearPairingCode() { if (pairingFile) await rm(pairingFile, { force: true }).catch(() => undefined); }

  const log = (record) => {
    const sanitized = sanitizeLog(record);
    logs.push(sanitized);
    if (logs.length > 200) logs.shift();
    if (!testMode) process.stdout.write(`${JSON.stringify(sanitized)}\n`);
  };

  async function probeOllama() {
    try {
      const [versionResponse, tagsResponse] = await Promise.all([ollamaFetch(ollamaEndpoint, "/api/version", { method: "GET" }, 2_000), ollamaFetch(ollamaEndpoint, "/api/tags", { method: "GET" }, 2_000)]);
      const version = await versionResponse.json();
      const tags = await tagsResponse.json();
      const models = Array.isArray(tags.models) ? tags.models.map(modelProfileFromTag) : [];
      return { reachable: true, version: version.version ?? null, models };
    } catch (error) { return { reachable: false, version: null, models: [], errorCode: error.code || "OLLAMA_UNREACHABLE" }; }
  }

  function authenticate(request, origin, requireCsrf = request.method !== "GET") {
    return pairing.authorize(origin, bearer(request), request.headers["x-bridge-csrf"], { requireCsrf });
  }

  const server = http.createServer(async (request, response) => {
    let origin;
    let requestErrorCode = null;
    const accessRecord = {
      timestamp: new Date().toISOString(),
      request_received: true,
      method: request.method || null,
      path: String(request.url || "/").split("?", 1)[0],
      host: String(request.headers.host || ""),
      origin: String(request.headers.origin || ""),
      user_agent: String(request.headers["user-agent"] || ""),
      protocol: String(request.headers["x-bridge-protocol"] || ""),
      secFetchSite: String(request.headers["sec-fetch-site"] || ""),
      secFetchMode: String(request.headers["sec-fetch-mode"] || ""),
      privateNetworkRequested: String(request.headers["access-control-request-private-network"] || "").toLowerCase() === "true",
      preflight_private_network: String(request.headers["access-control-request-private-network"] || "").toLowerCase() === "true",
      remoteLoopback: ["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(String(request.socket.remoteAddress || "")),
      cors_decision: "not_evaluated",
      origin_decision: "not_evaluated",
      host_decision: "not_evaluated",
    };
    response.once("finish", () => {
      const requestState = response.statusCode < 400
        ? "SUCCESS"
        : requestErrorCode === "HOST_VALIDATION_FAILED" ? "HOST_REJECTED"
          : requestErrorCode === "BRIDGE_ORIGIN_NOT_ALLOWED" ? "ORIGIN_REJECTED"
            : requestErrorCode === "CORS_PREFLIGHT_REJECTED" ? "OPTIONS_REJECTED"
              : requestErrorCode === "BRIDGE_NOT_PAIRED" ? "PAIRING_REQUIRED"
                : request.method === "OPTIONS" ? "OPTIONS_RECEIVED" : "GET_RECEIVED";
      const row = { ...accessRecord, request_state: requestState, response_status: response.statusCode, failure_code: requestErrorCode, status: response.statusCode, errorCode: requestErrorCode };
      accessLogs.push(row);
      if (accessLogs.length > 500) accessLogs.shift();
      if (accessLogPath) void appendFile(accessLogPath, `${JSON.stringify(row)}\n`, { encoding: "utf8", mode: 0o600 }).catch(() => undefined);
    });
    try {
      accessRecord.host_decision = "checking";
      validateHostHeader(request.headers.host, port);
      accessRecord.host_decision = "allowed";
      accessRecord.origin_decision = "checking";
      origin = assertOrigin(request.headers.origin, allowlist);
      accessRecord.origin_decision = "allowed";
      if (request.method === "OPTIONS") {
        accessRecord.cors_decision = "checking";
        const requestedHeaders = String(request.headers["access-control-request-headers"] || "").toLowerCase();
        const requestedMethod = String(request.headers["access-control-request-method"] || "GET").toUpperCase();
        if (!requestedHeaders.includes("x-bridge-protocol") || (requestedMethod === "POST" && !requestedHeaders.includes("content-type"))) throw new BridgeError("CORS_PREFLIGHT_REJECTED", "Preflight does not request required bridge headers.", 403);
        const privateNetworkRequested = String(request.headers["access-control-request-private-network"] || "").toLowerCase() === "true";
        response.writeHead(204, {
          "Access-Control-Allow-Origin": origin,
          Vary: "Origin, Access-Control-Request-Private-Network",
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
          "Access-Control-Allow-Headers": "Authorization,Content-Type,X-Bridge-Protocol,X-Bridge-CSRF,Idempotency-Key",
          ...(privateNetworkRequested ? { "Access-Control-Allow-Private-Network": "true" } : {}),
          "Access-Control-Max-Age": "300",
        });
        accessRecord.cors_decision = "allowed";
        response.end(); return;
      }
      assertProtocol(request.headers["x-bridge-protocol"]);
      const url = new URL(request.url, `http://${request.headers.host}`);
      if (url.searchParams.has("token") || url.searchParams.has("authorization")) throw new BridgeError("LOCAL_SECURITY_POLICY_VIOLATION", "Credentials are not accepted in URLs.", 400);
      const isInferenceRequest = request.method === "POST" && (
        url.pathname === "/generate" ||
        url.pathname === "/model/verify"
      );
      (isInferenceRequest ? inferenceRate : controlRate).take(origin);

      if (request.method === "GET" && url.pathname === "/health") {
        const ollama = await probeOllama();
        const state = pairing.state();
        return sendJson(response, 200, { bridgeProcessAlive: true, bridgeVersion: BRIDGE_VERSION, protocolVersion: BRIDGE_PROTOCOL, instanceId: pairing.instanceId, providerKind: "local_ollama", operatingSystem: `${os.platform()} ${os.release()}`, supportedOperations: ["health", "trusted-origin-auto-session", "pairing", "models", "model-verify", "generate", "stream", "cancel", "cache-stats", "targeted-cache-invalidation"], streamingSupport: true, cancellationSupport: true, maximumRequestSize: limits.maxPromptBytes, configuredOrigins: [...allowlist], automaticSessionSupported: trustedAutoSessionOrigins.has(origin), securityMode: "loopback-origin-bound-short-session", bindAddress: host, pairingState: state, ollamaReachable: ollama.reachable, ollamaVersion: ollama.version, modelAvailable: ollama.models.some((item) => item.capabilities.textGeneration.value), runtimeReady: state === "paired" && ollama.reachable && ollama.models.some((item) => item.capabilities.textGeneration.value), cache: await cache.stats(), workload: { active: work.active, queued: work.queue.length, maxConcurrent: work.maxConcurrent, maxQueue: work.maxQueue }, limits }, origin);
      }

      if (request.method === "POST" && url.pathname === "/session/auto") {
        const body = await readJson(request, 1_024);
        if (body.intent !== "closed-ai-connect") throw new BridgeError("LOCAL_SECURITY_POLICY_VIOLATION", "Automatic connection intent is invalid.", 400);
        if (!trustedAutoSessionOrigins.has(origin)) throw new BridgeError("BRIDGE_ORIGIN_NOT_ALLOWED", "This exact origin is not enabled for passwordless local connection.", 403);
        const session = pairing.issueTrustedOriginSession(origin);
        return sendJson(response, 200, {
          ...session,
          protocolVersion: BRIDGE_PROTOCOL,
          automaticConnection: true,
        }, origin);
      }

      if (request.method === "POST" && url.pathname === "/pair/request") {
        await readJson(request, 1_024);
        const pending = pairing.request(origin);
        await publishPairingCode(pending, origin);
        return sendJson(response, 201, { pairingId: pending.pairingId, expiresAt: pending.expiresAt, state: pending.state, instanceId: pairing.instanceId, protocolVersion: BRIDGE_PROTOCOL, ...(testMode ? { testCode: pending.code } : {}) }, origin);
      }

      if (request.method === "POST" && url.pathname === "/pair/confirm") {
        const body = await readJson(request, 2_048);
        const session = pairing.confirm(String(body.pairingId || ""), String(body.code || ""), origin);
        await clearPairingCode();
        return sendJson(response, 200, session, origin);
      }

      if (request.method === "POST" && url.pathname === "/pair/revoke") {
        const body = await readJson(request, 1_024);
        if (body.confirm !== true) throw new BridgeError("OLLAMA_REQUEST_REJECTED", "Revocation confirmation is required.", 400);
        return sendJson(response, 200, pairing.revoke(origin, bearer(request), request.headers["x-bridge-csrf"]), origin);
      }

      if (request.method === "GET" && url.pathname === "/cache/stats") {
        authenticate(request, origin, false);
        return sendJson(response, 200, { cache: await cache.stats() }, origin);
      }

      if (request.method === "POST" && url.pathname === "/cache/invalidate") {
        authenticate(request, origin);
        const body = await readJson(request, 16_384);
        let invalidatedEntries;
        try {
          invalidatedEntries = await cache.invalidate(body);
        } catch (error) {
          throw cacheRequestError(error);
        }
        return sendJson(response, 200, {
          status: "completed",
          targeted: true,
          invalidatedEntries,
          canonicalMutationCount: 0,
        }, origin);
      }

      if (request.method === "GET" && url.pathname === "/models") {
        authenticate(request, origin, false);
        const result = await probeOllama();
        if (!result.reachable) throw new BridgeError(result.errorCode || "OLLAMA_UNREACHABLE", "Ollama model discovery failed.", 503, true);
        return sendJson(response, 200, { providerKind: "local_ollama", models: result.models }, origin);
      }

      if (request.method === "GET" && url.pathname.startsWith("/models/")) {
        authenticate(request, origin, false);
        const modelId = decodeURIComponent(url.pathname.slice(8));
        if (!modelId || modelId.length > 200 || /[\\/?#\0]/.test(modelId)) throw new BridgeError("OLLAMA_MODEL_NOT_FOUND", "Model ID is invalid.", 404);
        const tagsResponse = await ollamaFetch(ollamaEndpoint, "/api/tags", { method: "GET" });
        const tags = await tagsResponse.json();
        const tag = (tags.models || []).find((item) => (item.model || item.name) === modelId);
        if (!tag) throw new BridgeError("OLLAMA_MODEL_NOT_FOUND", "Model is not installed.", 404);
        const showResponse = await ollamaFetch(ollamaEndpoint, "/api/show", { method: "POST", body: JSON.stringify({ model: modelId, verbose: false }) }, 10_000);
        const show = await showResponse.json();
        return sendJson(response, 200, { ...modelProfileFromTag(tag), inspection: { capabilities: show.capabilities ?? null, source: show.capabilities ? "reported" : "unknown" } }, origin);
      }

      if (request.method === "POST" && url.pathname === "/model/verify") {
        authenticate(request, origin);
        const body = await readJson(request, 2_048);
        const modelId = String(body.model || "");
        if (!modelId || modelId.length > 200 || /[\\/?#\0]/.test(modelId)) {
          throw new BridgeError("OLLAMA_MODEL_NOT_FOUND", "Model ID is invalid.", 404);
        }
        const tagsResponse = await ollamaFetch(
          ollamaEndpoint,
          "/api/tags",
          { method: "GET" },
          LOCAL_BRIDGE_MODEL_DISCOVERY_SERVER_TIMEOUT_MS,
        );
        const tags = await tagsResponse.json();
        const tag = (tags.models || []).find((item) => (item.model || item.name) === modelId);
        if (!tag) throw new BridgeError("OLLAMA_MODEL_NOT_FOUND", "Model is not installed.", 404);
        const profile = modelProfileFromTag(tag);
        if (profile.capabilities.textGeneration.value !== true) {
          throw new BridgeError("OLLAMA_REQUEST_REJECTED", "Selected model cannot generate text.", 400);
        }
        const verificationKey = `${pairing.instanceId}\u0000${modelId}\u0000${profile.modelDigest ?? "unknown"}`;
        const cachedVerification = modelVerificationCache.get(verificationKey);
        let verification = cachedVerification?.expiresAt > Date.now()
          ? Promise.resolve(cachedVerification.proof)
          : modelVerificationInFlight.get(verificationKey);
        if (!verification) {
          verification = (async () => {
            const startedAt = performance.now();
            const verifyResponse = await ollamaFetch(ollamaEndpoint, "/api/generate", {
              method: "POST",
              body: JSON.stringify({
                model: modelId,
                prompt: "這是本機模型啟動驗證。請只回覆四個字：驗證完成",
                system: "You are a local runtime health verifier. Follow the fixed instruction and do not add explanations.",
                stream: false,
                keep_alive: "10m",
                options: { temperature: 0, seed: 7, num_ctx: 512, num_predict: 8 },
              }),
            }, LOCAL_BRIDGE_MODEL_INFERENCE_SERVER_TIMEOUT_MS);
            const verifyBody = await verifyResponse.json().catch(() => null);
            const output = String(verifyBody?.response || "").trim();
            if (!output) {
              throw new BridgeError("LOCAL_MODEL_INFERENCE_NOT_VERIFIED", "Model returned no output during inference verification.", 502, true);
            }
            const outputDigest = Buffer.from(
              await crypto.subtle.digest("SHA-256", new TextEncoder().encode(output)),
            ).toString("hex");
            const proof = {
              proofVersion: "local-model-inference-proof-v1",
              state: "inference_verified",
              providerKind: "local_ollama",
              instanceId: pairing.instanceId,
              modelId,
              modelDigest: profile.modelDigest,
              verifiedAt: new Date().toISOString(),
              latencyMs: Math.round(performance.now() - startedAt),
              outputDigest,
              outputBytes: Buffer.byteLength(output, "utf8"),
              evalCount: Number(verifyBody?.eval_count) || null,
              externalRequest: false,
              dataLeftDevice: false,
            };
            modelVerificationCache.set(verificationKey, {
              proof,
              expiresAt: Date.now() + LOCAL_BRIDGE_MODEL_VERIFICATION_CACHE_TTL_MS,
            });
            log({ requestId: `model-verify:${outputDigest.slice(0, 16)}`, taskType: "model.verify", modelId, elapsedMs: proof.latencyMs, status: "completed", errorCode: null });
            return proof;
          })();
          modelVerificationInFlight.set(verificationKey, verification);
          void verification.finally(() => {
            if (modelVerificationInFlight.get(verificationKey) === verification) {
              modelVerificationInFlight.delete(verificationKey);
            }
          }).catch(() => undefined);
        }
        const proof = await verification;
        return sendJson(response, 200, proof, origin);
      }

      if (request.method === "POST" && url.pathname === "/cancel") {
        authenticate(request, origin);
        const body = await readJson(request, 2_048);
        const controller = active.get(String(body.requestId || ""));
        if (!controller) throw new BridgeError("OLLAMA_CANCELLED", "Request is not active.", 404);
        controller.abort("cancelled");
        return sendJson(response, 202, { requestId: body.requestId, state: "cancelled" }, origin);
      }

      if (request.method === "POST" && url.pathname === "/generate") {
        authenticate(request, origin);
        const body = await readJson(request, limits.maxPromptBytes + 8_192);
        const requestId = String(body.requestId || request.headers["idempotency-key"] || "");
        const modelId = String(body.model || "");
        const prompt = Array.isArray(body.messages) ? body.messages.map((item) => `${item.role}: ${item.content}`).join("\n") : String(body.prompt || "");
        if (!requestId || !/^[A-Za-z0-9._:-]{8,128}$/.test(requestId)) throw new BridgeError("OLLAMA_REQUEST_REJECTED", "A structured request ID is required.", 400);
        if (Buffer.byteLength(prompt, "utf8") > limits.maxPromptBytes) throw new BridgeError("LOCAL_REQUEST_TOO_LARGE", "Prompt exceeds the local bridge limit.", 413);
        if (!modelId || modelId.length > 200 || /[\\/?#\0]/.test(modelId)) throw new BridgeError("OLLAMA_MODEL_NOT_FOUND", "Model ID is invalid.", 404);
        const maxTokens = Math.min(Number(body.options?.num_predict || limits.maxOutputTokens), limits.maxOutputTokens);
        const timeoutMs = Math.min(Math.max(Number(body.timeoutMs || 60_000), 100), limits.maxTimeoutMs);
        let cacheNamespace = null;
        try {
          cacheNamespace = body.cacheNamespace
            ? assertRuntimeCacheNamespace(body.cacheNamespace)
            : null;
        } catch (error) {
          throw cacheRequestError(error);
        }
        if (cacheNamespace && cacheNamespace.modelId !== modelId) {
          throw new BridgeError(
            "LOCAL_REQUEST_IDENTITY_MISMATCH",
            "Cache namespace model identity does not match the selected model.",
            409,
          );
        }
        if (cacheNamespace?.privacyLevel === "private_infrastructure_only") {
          throw new BridgeError(
            "LOCAL_SECURITY_POLICY_VIOLATION",
            "Private-infrastructure cache scope cannot be written by Local Ollama.",
            403,
          );
        }
        const generationCacheInput = {
          prompt,
          systemInstruction: String(body.systemInstruction || ""),
          taskType: String(body.taskType || "unknown"),
          modelId,
          options: body.options || {},
          maxTokens,
        };
        const tagsResponse = await ollamaFetch(
          ollamaEndpoint,
          "/api/tags",
          { method: "GET" },
          5_000,
        );
        const tags = await tagsResponse.json();
        const selectedModel = (tags.models || []).find(
          (item) => (item.model || item.name) === modelId,
        );
        if (!selectedModel) {
          throw new BridgeError("OLLAMA_MODEL_NOT_FOUND", "Model is not installed.", 404);
        }
        if (
          cacheNamespace
          && selectedModel.digest
          && cacheNamespace.modelDigest !== selectedModel.digest
        ) {
          throw new BridgeError(
            "LOCAL_REQUEST_IDENTITY_MISMATCH",
            "Cache namespace model digest does not match the installed model.",
            409,
          );
        }
        const cached = cacheNamespace
          ? await cache.get("exact", cacheNamespace, generationCacheInput)
          : { hit: false, entry: null };
        if (cached.hit && cached.entry?.value?.content) {
          const cachedValue = cached.entry.value;
          response.writeHead(200, { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store", "Access-Control-Allow-Origin": origin, Vary: "Origin", "X-Content-Type-Options": "nosniff" });
          response.write(`${JSON.stringify({ type: "started", requestId, modelId, cacheHit: true })}\n`);
          response.write(`${JSON.stringify({ type: "token", text: cachedValue.content, cacheHit: true })}\n`);
          response.write(`${JSON.stringify({ type: "metadata", ...(cachedValue.metadata || {}), cacheHit: true })}\n`);
          response.write(`${JSON.stringify({ type: "completed", requestId, cacheHit: true })}\n`);
          response.end();
          log({ requestId, taskType: body.taskType, modelId, elapsedMs: 0, status: "completed", cacheHit: true, errorCode: null });
          return;
        }
        ledger.begin(requestId, JSON.stringify({ origin, modelId, promptHash: Buffer.from(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(prompt))).toString("hex"), taskType: body.taskType || "unknown" }));
        const release = await work.acquire();
        const controller = new AbortController();
        const totalTimer = setTimeout(() => controller.abort("timeout"), timeoutMs);
        active.set(requestId, controller);
        const startedAt = performance.now();
        let status = "failed";
        try {
          const format = body.taskType === "character.extract" ? characterExtractionFormat : undefined;
          const upstream = await ollamaFetch(ollamaEndpoint, "/api/generate", { method: "POST", body: JSON.stringify({ model: modelId, prompt, system: body.systemInstruction || undefined, stream: true, format, keep_alive: "30m", options: { ...(body.options || {}), num_predict: maxTokens } }) }, timeoutMs, controller);
          response.writeHead(200, { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store", "Access-Control-Allow-Origin": origin, Vary: "Origin", "X-Content-Type-Options": "nosniff" });
          response.write(`${JSON.stringify({ type: "started", requestId, modelId })}\n`);
          const reader = upstream.body?.getReader();
          if (!reader) throw new BridgeError("OLLAMA_INVALID_RESPONSE", "Ollama response has no stream.", 502);
          const decoder = new TextDecoder();
          let buffer = "", tokenCount = 0, metadata = {}, generatedContent = "";
          while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n"); buffer = lines.pop() || "";
            for (const line of lines) {
              if (!line.trim()) continue;
              let item; try { item = JSON.parse(line); } catch { throw new BridgeError("OLLAMA_INVALID_RESPONSE", "Ollama returned invalid stream JSON.", 502); }
              if (item.response) { tokenCount += 1; generatedContent += item.response; response.write(`${JSON.stringify({ type: "token", text: item.response })}\n`); }
              if (item.done) metadata = { totalDuration: item.total_duration ?? null, loadDuration: item.load_duration ?? null, promptEvalCount: item.prompt_eval_count ?? null, evalCount: item.eval_count ?? null };
            }
          }
          if (cacheNamespace && generatedContent) {
            await cache.put({
              layer: "exact",
              namespace: cacheNamespace,
              input: generationCacheInput,
              value: { content: generatedContent, modelId, metadata },
              tags: ["generation", `task:${body.taskType || "unknown"}`],
            });
            await cache.put({
              layer: "model-session",
              namespace: cacheNamespace,
              input: {
                storyId: cacheNamespace.storyId,
                branchId: cacheNamespace.branchId,
                modelId,
              },
              value: {
                runtime: "ollama",
                modelId,
                keepAlive: "runtime-managed",
                stateKind: "runtime_handle_metadata_only",
              },
              ttlMs: 10 * 60_000,
              tags: ["model-session"],
            });
          }
          response.write(`${JSON.stringify({ type: "metadata", tokenEvents: tokenCount, ...metadata })}\n`);
          response.write(`${JSON.stringify({ type: "completed", requestId })}\n`);
          response.end(); status = "completed";
        } catch (error) {
          const effective = controller.signal.aborted ? new BridgeError(controller.signal.reason === "cancelled" ? "OLLAMA_CANCELLED" : "OLLAMA_TIMEOUT", controller.signal.reason === "cancelled" ? "Ollama generation was cancelled." : "Ollama generation timed out.", 408, true) : error;
          status = effective.code === "OLLAMA_CANCELLED" ? "cancelled" : "failed";
          if (!response.headersSent) sendJson(response, effective.status || 500, { errorCode: effective.code || "OLLAMA_INVALID_RESPONSE", message: effective.message, retryable: Boolean(effective.retryable), requestId }, origin);
          else { response.write(`${JSON.stringify({ type: status, errorCode: effective.code || "OLLAMA_STREAM_INTERRUPTED", message: effective.message })}\n`); response.end(); }
        } finally {
          clearTimeout(totalTimer); active.delete(requestId); release(); ledger.finish(requestId, status);
          log({ requestId, taskType: body.taskType, modelId, elapsedMs: Math.round(performance.now() - startedAt), status, errorCode: status === "completed" ? null : status === "cancelled" ? "OLLAMA_CANCELLED" : "OLLAMA_STREAM_INTERRUPTED" });
        }
        return;
      }

      throw new BridgeError("OLLAMA_REQUEST_REJECTED", "Route not found.", 404);
    } catch (error) {
      const bridgeError = error instanceof BridgeError ? error : new BridgeError("OLLAMA_INVALID_RESPONSE", "Local bridge request failed.", 500);
      requestErrorCode = bridgeError.code;
      if (bridgeError.code === "HOST_VALIDATION_FAILED") accessRecord.host_decision = "rejected";
      if (bridgeError.code === "BRIDGE_ORIGIN_NOT_ALLOWED") accessRecord.origin_decision = "rejected";
      if (bridgeError.code === "CORS_PREFLIGHT_REJECTED") accessRecord.cors_decision = "rejected";
      if (!response.headersSent) sendJson(response, bridgeError.status, { errorCode: bridgeError.code, message: bridgeError.message, retryable: bridgeError.retryable, details: bridgeError.details }, origin);
      else response.end();
    }
  });

  server.on("clientError", (_error, socket) => socket.end("HTTP/1.1 400 Bad Request\r\n\r\n"));
  return { server, config: { host, port, ollamaEndpoint, limits, allowlist: [...allowlist], instanceId: pairing.instanceId }, pairing, cache, logs, accessLogs, active, async start() { await cache.initialize(); if (accessLogPath) await writeFile(accessLogPath, "", { mode: 0o600 }); await new Promise((resolve, reject) => { server.once("error", reject); server.listen(port, host, () => { server.off("error", reject); resolve(); }); }); return this; }, async stop() { for (const controller of active.values()) controller.abort("cancelled"); await clearPairingCode(); server.closeIdleConnections?.(); await new Promise((resolve) => server.close(resolve)); server.closeAllConnections?.(); await cache.close?.(); } };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const bridge = createBridgeServer();
  bridge.start().then(() => process.stdout.write(`${JSON.stringify({ event: "bridge_started", protocol: BRIDGE_PROTOCOL, host: bridge.config.host, port: bridge.config.port, instanceId: bridge.config.instanceId })}\n`)).catch((error) => { process.stderr.write(`${error.code || "BRIDGE_START_FAILED"}: ${error.message}\n`); process.exitCode = 1; });
  for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => bridge.stop().finally(() => process.exit(0)));
}
